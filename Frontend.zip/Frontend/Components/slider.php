<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Wi-Fi Publictaion</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="shortcut icon" href="./images/favicon.ico" type="image/x-icon">
  </head>
  <body>

  <style>

    
    .slider
    {
        height:580px;
    }
  </style>

  <div id="carouselExampleCaptions" class="carousel slide mb-5" data-bs-ride="false">
  <!-- <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div> -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="./images/slider2.webp" class="d-block w-100 slider" alt="...">
      <div class="carousel-caption d-none d-md-block ">
        <h5>First slide label</h5>
        <p>Some representative placeholder content for the first slide.</p>
        <button class="btn border-0 text-light p-3" style="background-color:#0cc5cd;">Get Started For Free</button>
        <button class="btn border-0 text-light p-3" style="background-color:#000;">Get More Info</button>
      </div>
    </div>
    <div class="carousel-item">
      <img src="./images/slider1.webp" class="d-block w-100 slider" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5>Second slide label</h5>
        <p>Some representative placeholder content for the second slide.</p>
        <button class="btn border-0 text-light p-3" style="background-color:#0cc5cd;">Get Started For Free</button>
        <button class="btn border-0 text-light p-3" style="background-color:#000;">Get More Info</button>
      </div>
    </div>
    <div class="carousel-item">
      <img src="./images/slider2.webp" class="d-block w-100 slider" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5>Third slide label</h5>
        <p>Some representative placeholder content for the third slide.</p>
        <button class="btn border-0 text-light p-3" style="background-color:#0cc5cd;">Get Started For Free</button>
        <button class="btn border-0 text-light p-3" style="background-color:#000;">Get More Info</button>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon "  aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
    

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>
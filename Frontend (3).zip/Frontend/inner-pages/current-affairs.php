<?php include("../components/Navbar.php") ?>

<style>
    ol li
    {
        font-size :13px;
    }
</style>

<div class="container">
    <div class="row mb-5">
    <h4 class="text-center mb-5 mt-5" style="font-family: 'Ubuntu', sans-serif; font-weight:bold;">DAILY CURRENT AFFAIRS <span class="text-muted">PDF NOTES</span></h4>

    

<div class="col-sm-3">

            <div class="card  border-0 shadow" style="width: 18rem;">
           
  <div class="card-body">
  <h5 class="card-title text-center">FOR 3 MONTH</h5>
            <h6 class="text-center"><span class="text-info ">LANGUAGE</span>-HINDI</h6>
            <br>
            <ol>
                <li>DAILY CURRENT AFFAIRS</li>
                <li>WEEKLY ONE LINER</li>
                <li>WEEKLY QUIZ</li>
                <li>MONTHLY ONE LINER</li>
                <li>MONTHLY QUIZ</li>

            </ol>
   
    <p class="text-center">Price:-<span> ₹500</span></p>
    <button class="btn btn-info px-4 w-100 text-light">BUY</button>
  

  </div>

            </div>
</div>
<div class="col-sm-3">

            <div class="card  border-0 shadow" style="width: 18rem;">
           
  <div class="card-body">
  <h5 class="card-title text-center">FOR 6 MONTH</h5>
            <h6 class="text-center"><span class="text-info ">LANGUAGE</span>-HINDI</h6>
            <br>
            <ol>
                <li>DAILY CURRENT AFFAIRS</li>
                <li>WEEKLY ONE LINER</li>
                <li>WEEKLY QUIZ</li>
                <li>MONTHLY ONE LINER</li>
                <li>MONTHLY QUIZ</li>

            </ol>
   
    <p class="text-center">Price:-<span> ₹500</span></p>
    <button class="btn btn-info px-4 w-100 text-light">BUY</button>
  

  </div>

            </div>
</div>

<div class="col-sm-3">

            <div class="card  border-0 shadow" style="width: 18rem;">
           
  <div class="card-body">
  <h5 class="card-title text-center">FOR 1 YEAR</h5>
            <h6 class="text-center"><span class="text-info ">LANGUAGE</span>-HINDI/ENGLISH</h6>
            <br>
            <ol>
                <li>DAILY CURRENT AFFAIRS</li>
                <li>WEEKLY ONE LINER</li>
                <li>WEEKLY QUIZ</li>
                <li>MONTHLY ONE LINER</li>
                <li>MONTHLY QUIZ</li>

            </ol>
   
    <p class="text-center">Price:-<span> ₹500</span></p>
    <button class="btn btn-info px-4 w-100 text-light">BUY</button>
  

  </div>

            </div>
</div>

<div class="col-sm-3">

            <div class="card  border-0 shadow" style="width: 18rem;">
           
  <div class="card-body">
  <h5 class="card-title text-center">FOR 5 MONTH</h5>
            <h6 class="text-center"><span class="text-info ">LANGUAGE</span>-HINDI/ENGLISH</h6>
            <br>
            <ol>
                <li>DAILY CURRENT AFFAIRS</li>
                <li>WEEKLY ONE LINER</li>
                <li>WEEKLY QUIZ</li>
                <li>MONTHLY ONE LINER</li>
                <li>MONTHLY QUIZ</li>

            </ol>
   
    <p class="text-center">Price:-<span> ₹500</span></p>
    <button class="btn btn-info px-4 w-100 text-light">BUY</button>
  

  </div>

            </div>
</div>
</div>


    <div class="row mb-5">
    <div class="col-sm-3">

<div class="card  border-0 shadow" style="width: 18rem;">

<div class="card-body">
<h5 class="card-title text-center">FOR 4 MONTH</h5>
<h6 class="text-center"><span class="text-info ">LANGUAGE</span>-HINDI</h6>
<br>
<ol>
    <li>DAILY CURRENT AFFAIRS</li>
    <li>WEEKLY ONE LINER</li>
    <li>WEEKLY QUIZ</li>
    <li>MONTHLY ONE LINER</li>
    <li>MONTHLY QUIZ</li>

</ol>

<p class="text-center">Price:-<span> ₹500</span></p>
<button class="btn btn-info px-4 w-100 text-light">BUY</button>


</div>

</div>
</div>

<div class="col-sm-3">

            <div class="card  border-0 shadow" style="width: 18rem;">
           
  <div class="card-body">
  <h5 class="card-title text-center">FOR 6 MONTH</h5>
            <h6 class="text-center"><span class="text-info ">LANGUAGE</span>-HINDI/ENGLISH</h6>
            <br>
            <ol>
                <li>DAILY CURRENT AFFAIRS</li>
                <li>WEEKLY ONE LINER</li>
                <li>WEEKLY QUIZ</li>
                <li>MONTHLY ONE LINER</li>
                <li>MONTHLY QUIZ</li>

            </ol>
   
    <p class="text-center">Price:-<span> ₹500</span></p>
    <button class="btn btn-info px-4 w-100 text-light">BUY</button>
  

  </div>

            </div>
</div>

<div class="col-sm-3">

            <div class="card  border-0 shadow" style="width: 18rem;">
           
  <div class="card-body">
  <h5 class="card-title text-center">FOR 2 MONTH</h5>
            <h6 class="text-center"><span class="text-info ">LANGUAGE</span>-ENGLISH</h6>
            <br>
            <ol>
                <li>DAILY CURRENT AFFAIRS</li>
                <li>WEEKLY ONE LINER</li>
                <li>WEEKLY QUIZ</li>
                <li>MONTHLY ONE LINER</li>
                <li>MONTHLY QUIZ</li>

            </ol>
   
    <p class="text-center">Price:-<span> ₹500</span></p>
    <button class="btn btn-info px-4 w-100 text-light">BUY</button>
  

  </div>

            </div>
</div>

<div class="col-sm-3">

            <div class="card  border-0 shadow" style="width: 18rem;">
           
  <div class="card-body">
  <h5 class="card-title text-center">FOR 1 YEAR</h5>
            <h6 class="text-center"><span class="text-info ">LANGUAGE</span>-ENGLISH</h6>
            <br>
            <ol>
                <li>DAILY CURRENT AFFAIRS</li>
                <li>WEEKLY ONE LINER</li>
                <li>WEEKLY QUIZ</li>
                <li>MONTHLY ONE LINER</li>
                <li>MONTHLY QUIZ</li>

            </ol>
   
    <p class="text-center">Price:-<span> ₹500</span></p>
    <button class="btn btn-info px-4 w-100 text-light">BUY</button>
  

  </div>

            </div>
</div>

    </div>
    

   


  
     

</div>



<?php include("../components/footer.php") ?>
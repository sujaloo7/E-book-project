<?php include("../components/Navbar.php") ?>


<div class="container mt-5 mb-5">
        <div class="row mb-5">
            <h4 class="text-center mb-5 text-muted" style="font-family: 'Ubuntu', sans-serif; font-weight:bold;">NOTES</h4>

            <div class="col-sm-3">

<div class="card  border-0 shadow" style="width: 18rem;">

<div class="card-body text-center">
<h5 class="card-title text-center btn btn-info w-100 text-light disabled">MATH</h5>

<br>
<!-- <p>TOTAL TOPIC - 35</p> -->
<p>STATE G.K. NOTES</p>


<p class="text-center">Price:-<span> ₹4500</span></p>
<button class="btn btn-info px-4 w-100 text-light">BUY</button>


</div>

</div>
</div>

<div class="col-sm-3">

<div class="card  border-0 shadow" style="width: 18rem;">

<div class="card-body text-center">
<h5 class="card-title text-center btn btn-info w-100 text-light disabled">REASONING</h5>
<br>
<p>INDIA G. K. NOTES</p>



<p class="text-center">Price:-<span> ₹4500</span></p>
<button class="btn btn-info px-4 w-100 text-light">BUY</button>


</div>

</div>
</div>

<div class="col-sm-3">

<div class="card  border-0 shadow" style="width: 18rem;">

<div class="card-body text-center">
<h5 class="card-title text-center btn btn-info w-100 text-light disabled">ENGLISH</h5>
<br>
<p>SCIENCE NOTES</p>


<p class="text-center">Price:-<span> ₹4500</span></p>
<button class="btn btn-info px-4 w-100 text-light">BUY</button>


</div>

</div>
</div>

<div class="col-sm-3">

<div class="card  border-0 shadow" style="width: 18rem;">

<div class="card-body text-center">
<h5 class="card-title text-center btn btn-info w-100 text-light disabled">GK / GS</h5>
<!-- <h6 class="text-center"><span class="text-info ">LANGUAGE</span>-HINDI</h6> -->
<br>
<p>ENGLISH NOTES</p>


<p class="text-center">Price:-<span> ₹4500</span></p>
<button class="btn btn-info px-4 w-100 text-light">BUY</button>


</div>

</div>
</div>
         

            
        </div>

        <div class="row mb-5">
            <!-- <h4 class="text-center mb-5 text-muted" style="font-family: 'Ubuntu', sans-serif; font-weight:bold;">NOTES</h4> -->

            <div class="col-sm-3">

<div class="card  border-0 shadow" style="width: 18rem;">

<div class="card-body text-center">
<h5 class="card-title text-center btn btn-info w-100 text-light disabled">MATH</h5>

<br>
<!-- <p>TOTAL TOPIC - 35</p> -->
<p>STATE G.K. NOTES</p>


<p class="text-center">Price:-<span> ₹4500</span></p>
<button class="btn btn-info px-4 w-100 text-light">BUY</button>


</div>

</div>
</div>

<div class="col-sm-3">

<div class="card  border-0 shadow" style="width: 18rem;">

<div class="card-body text-center">
<h5 class="card-title text-center btn btn-info w-100 text-light disabled">REASONING</h5>
<br>
<p>INDIA G. K. NOTES</p>



<p class="text-center">Price:-<span> ₹4500</span></p>
<button class="btn btn-info px-4 w-100 text-light">BUY</button>


</div>

</div>
</div>

<div class="col-sm-3">

<div class="card  border-0 shadow" style="width: 18rem;">

<div class="card-body text-center">
<h5 class="card-title text-center btn btn-info w-100 text-light disabled">ENGLISH</h5>
<br>
<p>SCIENCE NOTES</p>


<p class="text-center">Price:-<span> ₹4500</span></p>
<button class="btn btn-info px-4 w-100 text-light">BUY</button>


</div>

</div>
</div>

<div class="col-sm-3">

<div class="card  border-0 shadow" style="width: 18rem;">

<div class="card-body text-center">
<h5 class="card-title text-center btn btn-info w-100 text-light disabled">GK / GS</h5>
<!-- <h6 class="text-center"><span class="text-info ">LANGUAGE</span>-HINDI</h6> -->
<br>
<p>ENGLISH NOTES</p>


<p class="text-center">Price:-<span> ₹4500</span></p>
<button class="btn btn-info px-4 w-100 text-light">BUY</button>


</div>

</div>
</div>
         

            
        </div>


       
    </div>
<?php include("../components/footer.php") ?>
